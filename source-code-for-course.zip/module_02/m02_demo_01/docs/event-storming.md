# 📚 Monolithic BookStoreHub DDD Event Storming Details

https://gist.github.com/rupeshtiwari/e1c56cdc333b047c9826d0e08b3b8871 

