// In-memory database
let orders = [];
let orderHistory = {};
let rewards = {};
let payments = {};

module.exports = {
  orders,
  orderHistory,
  rewards,
  payments,
  // Add utility functions to interact with the database here
};
