// In-memory database
 
let rewards = {};
 

module.exports = {
   
  rewards,
 
  // Add utility functions to interact with the database here
};
